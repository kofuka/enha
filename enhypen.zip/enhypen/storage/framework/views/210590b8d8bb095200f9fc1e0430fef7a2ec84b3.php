<?php $__env->startSection('aside'); ?>
<div class="aside">
    <h4>I love Sunoo</h4>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime veniam iste officiis a necessitatibus, 
        praesentium cumque tenetur adipisci asperiores atque mollitia iusto itaque esse. Earum!</p>
        <?php echo $__env->yieldSection(); ?>
</div><?php /**PATH C:\OSPanel\domains\endocs\enhypen\resources\views/inc/aside.blade.php ENDPATH**/ ?>