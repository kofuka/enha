<div class="jumbotrom">
    <div class="container">

    </div>
</div><?php /**PATH C:\OSPanel\domains\endocs\enhypen\resources\views/inc/hero.blade.php ENDPATH**/ ?>